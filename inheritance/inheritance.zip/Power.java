package inheritance;

public interface Power {//공통기능 전원

	void on();
	//상속받는 클래스에서 구현해야하는 전원 on 메소드

	void off();
	//상속받는 클래스에서 구현해야하는 전원 off 메소드

}
