package inheritance;

public interface Keyboard extends Power{
//전원 기능을 상속받는 키보드
	void setkey();
	//상속받는 클래스에서 구현해야하는 키보드 메소드
	
}
