package inheritance;

public interface Moblie extends TV{
	//tv 기능을 상속받는 모바일
	  void minLight();
	//상속받는 클래스에서 구현해야하는 최소밝기 메소드
	  void restart();
	//상속받는 클래스에서 구현해야하는 재시작 메소드

}
