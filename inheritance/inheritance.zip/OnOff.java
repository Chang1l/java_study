package inheritance;

public class OnOff extends TestOnoff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestOnoff t = new TestOnoff();// 객체 생성

		t.TVshow();
		t.Radioshow();
		t.KeyBoardshow();
		t.Moboileshow();

//		t.lightup();
//		t.lightup();
//		t.lightdown();
//		t.lightdown();
//		t.lightdown();
//		t.lightup();
//		t.lightup();
//		t.lightup();
//		t.volup();
//		for(int i=0; i<101;i++) {
//			t.lightup();
//		}
	}

}
